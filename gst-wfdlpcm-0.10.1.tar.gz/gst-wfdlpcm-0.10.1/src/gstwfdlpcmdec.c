/*
 * GStreamer
 * Copyright (C) 2005 Thomas Vander Stichele <thomas@apestaart.org>
 * Copyright (C) 2005 Ronald S. Bultje <rbultje@ronald.bitfreak.net>
 * Copyright (C) 2015 Panasonic Semiconductor Solutions  Co., Ltd.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * Alternatively, the contents of this file may be used under the
 * GNU Lesser General Public License Version 2.1 (the "LGPL"), in
 * which case the following provisions apply instead of the ones
 * mentioned above:
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/**
 * SECTION:element-wfdlpcmdec
 *
 * Describe wfdlpcmdec here.
 *
 * <refsect2>
 * <title>Example launch line</title>
 * |[
 * gst-launch -v -m fakesrc ! wfdlpcmdec ! fakesink silent=TRUE
 * ]|
 * </refsect2>
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gst/gst.h>

#include "gstwfdlpcmdec.h"

GST_DEBUG_CATEGORY_STATIC (gst_wfdlpcmdec_debug);
#define GST_CAT_DEFAULT gst_wfdlpcmdec_debug

/* Wfdlpcmdec signals and args */
enum
{
  /* FILL ME */
  LAST_SIGNAL
};

enum
{
  PROP_0,
  PROP_SILENT
};

/* the capabilities of the inputs and outputs.
 *
 * describe the real formats here.
 */
static GstStaticPadTemplate sink_factory = GST_STATIC_PAD_TEMPLATE ("sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("audio/x-private1-lpcm")
    );

static GstStaticPadTemplate src_factory = GST_STATIC_PAD_TEMPLATE ("src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("audio/x-raw-int, "
        "width = (int) 16, "
        "rate = (int) { 44100, 48000 }, "
        "channels = (int) 2, "
        "endianness = (int) BIG_ENDIAN, "
        "depth = (int) 16, " 
        "signed = (boolean) true")
    );

GST_BOILERPLATE (Gstwfdlpcmdec, gst_wfdlpcmdec, GstElement,
    GST_TYPE_ELEMENT);

static void gst_wfdlpcmdec_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_wfdlpcmdec_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);

static GstFlowReturn gst_wfdlpcmdec_chain (GstPad * pad, GstBuffer * buf);

/* GObject vmethod implementations */

static void
gst_wfdlpcmdec_base_init (gpointer gclass)
{
  GstElementClass *element_class = GST_ELEMENT_CLASS (gclass);

  gst_element_class_set_details_simple(element_class,
    "wfdlpcmdec",
    "Codec/Decoder/Audio",
    "Decode WFD LPCM into raw audio",
    "Panasonic Semiconductor Solutions  Co., Ltd.");

  gst_element_class_add_pad_template (element_class,
      gst_static_pad_template_get (&src_factory));
  gst_element_class_add_pad_template (element_class,
      gst_static_pad_template_get (&sink_factory));
}

/* initialize the wfdlpcmdec's class */
static void
gst_wfdlpcmdec_class_init (GstwfdlpcmdecClass * klass)
{
  GObjectClass *gobject_class;

  gobject_class = (GObjectClass *) klass;

  gobject_class->set_property = gst_wfdlpcmdec_set_property;
  gobject_class->get_property = gst_wfdlpcmdec_get_property;

  g_object_class_install_property (gobject_class, PROP_SILENT,
      g_param_spec_boolean ("silent", "Silent", "Produce verbose output",
          FALSE, G_PARAM_READWRITE));
}

/* initialize the new element
 * instantiate pads and add them to element
 * set pad calback functions
 * initialize instance structure
 */
static void
gst_wfdlpcmdec_init (Gstwfdlpcmdec * wfdlpcmdec,
    GstwfdlpcmdecClass * gclass)
{
  wfdlpcmdec->sinkpad = gst_pad_new_from_static_template (&sink_factory, "sink");
#if 0
  gst_pad_set_setcaps_function (wfdlpcmdec->sinkpad,
                                GST_DEBUG_FUNCPTR(gst_wfdlpcmdec_set_caps));
#endif
  gst_pad_set_chain_function (wfdlpcmdec->sinkpad,
                              GST_DEBUG_FUNCPTR(gst_wfdlpcmdec_chain));

  wfdlpcmdec->srcpad = gst_pad_new_from_static_template (&src_factory, "src");
  gst_pad_use_fixed_caps (wfdlpcmdec->srcpad);

  gst_element_add_pad (GST_ELEMENT (wfdlpcmdec), wfdlpcmdec->sinkpad);
  gst_element_add_pad (GST_ELEMENT (wfdlpcmdec), wfdlpcmdec->srcpad);

  wfdlpcmdec->next_timestamp = GST_CLOCK_TIME_NONE;
  wfdlpcmdec->caps_info = 0;
  wfdlpcmdec->rate = 0;
  wfdlpcmdec->width = 0;
  wfdlpcmdec->channels = 0;

  wfdlpcmdec->silent = TRUE;
}

static void
gst_wfdlpcmdec_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  Gstwfdlpcmdec *wfdlpcmdec = GST_WFDLPCMDEC (object);

  switch (prop_id) {
    case PROP_SILENT:
      wfdlpcmdec->silent = g_value_get_boolean (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

static void
gst_wfdlpcmdec_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec)
{
  Gstwfdlpcmdec *wfdlpcmdec = GST_WFDLPCMDEC (object);

  switch (prop_id) {
    case PROP_SILENT:
      g_value_set_boolean (value, wfdlpcmdec->silent);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

/* GstElement vmethod implementations */

/* chain function
 * this function does the actual processing
 */
#define WFD_LPCM_PES_PRIVATE_SIZE 4

static GstFlowReturn
gst_wfdlpcmdec_chain (GstPad * pad, GstBuffer * buf)
{
  Gstwfdlpcmdec *wfdlpcmdec;
  GstBuffer *subbuf;
  GstCaps *src_caps;
  guint size;
  guint samples;
  GstClockTimeDiff diff, one_sample;
  guint32 caps_info;
  guint8 *header;

  wfdlpcmdec = GST_WFDLPCMDEC (GST_OBJECT_PARENT (pad));

  if (GST_BUFFER_SIZE (buf) < 3) {
	GST_ELEMENT_ERROR (wfdlpcmdec, STREAM, FORMAT, (NULL),
					   ("buf is too small"));
	gst_buffer_unref (buf);
	return GST_FLOW_ERROR;
  }

  header = GST_BUFFER_DATA (buf);
  caps_info = ((header[2] << 8) | header[3]);

  /* set caps into src pad */
  if (caps_info != wfdlpcmdec->caps_info) {

    switch (caps_info & 0x38) {
    case 0x08:
      wfdlpcmdec->rate = 44100;
      break;
    case 0x10:
      wfdlpcmdec->rate = 48000;
      break;
    default:
	  GST_ELEMENT_WARNING (wfdlpcmdec, STREAM, FORMAT, (NULL),
						   ("rate is bad"));
      wfdlpcmdec->rate = 48000;
      break;
    }

    switch (caps_info & 0xC0) {
    case 0x0:
      wfdlpcmdec->width = 16;
      break;
    default:
	  GST_ELEMENT_WARNING (wfdlpcmdec, STREAM, FORMAT, (NULL),
						   ("width is bad"));
      wfdlpcmdec->width = 16;
      break;
    }

    switch (caps_info & 0x3) {
    case 0x00:
    case 0x01:
      wfdlpcmdec->channels = 2;
      break;
    default:
	  GST_ELEMENT_WARNING (wfdlpcmdec, STREAM, FORMAT, (NULL),
						   ("channels is bad"));
      wfdlpcmdec->channels = 2;
      break;
    }

    src_caps = gst_caps_new_simple ("audio/x-raw-int",
				    "rate", G_TYPE_INT, wfdlpcmdec->rate,
				    "channels", G_TYPE_INT, wfdlpcmdec->channels,
				    "endianness", G_TYPE_INT, BIG_ENDIAN,
				    "depth", G_TYPE_INT, wfdlpcmdec->width,
				    "width", G_TYPE_INT, wfdlpcmdec->width,
				    "signed", G_TYPE_BOOLEAN, TRUE, 
				    NULL);

    /* set src pad caps */
    if (!gst_pad_set_caps (wfdlpcmdec->srcpad, src_caps)) {
      
      GST_ELEMENT_ERROR (wfdlpcmdec, STREAM, FORMAT, (NULL),
			 ("Failed to configure output format"));
      gst_buffer_unref (buf);
      gst_caps_unref (src_caps);
      return GST_FLOW_NOT_NEGOTIATED;
    }
    gst_caps_unref (src_caps);

    wfdlpcmdec->caps_info = caps_info;
  }

  size = GST_BUFFER_SIZE (buf) - WFD_LPCM_PES_PRIVATE_SIZE;

  /* if size is not 1920, drop it */
  if (size != 1920) {
	gst_buffer_unref (buf);
	return GST_FLOW_OK;
  }

  samples = size / wfdlpcmdec->channels / (wfdlpcmdec->width / 8);
  subbuf = gst_buffer_create_sub (buf, WFD_LPCM_PES_PRIVATE_SIZE, size);

  gst_buffer_set_caps (subbuf, GST_PAD_CAPS (wfdlpcmdec->srcpad));
  if (GST_CLOCK_TIME_IS_VALID (wfdlpcmdec->next_timestamp)) {
    one_sample = GST_SECOND / wfdlpcmdec->rate;
    diff = GST_CLOCK_DIFF (GST_BUFFER_TIMESTAMP (buf),
			   wfdlpcmdec->next_timestamp);
    if (diff > one_sample || diff < -one_sample) {
      GST_BUFFER_TIMESTAMP (subbuf) = GST_BUFFER_TIMESTAMP (buf);
      if (wfdlpcmdec->silent == FALSE) g_print("diff = %lld\n", diff/one_sample);
    }
    else {
      GST_BUFFER_TIMESTAMP (subbuf) = wfdlpcmdec->next_timestamp;
    }
  }
  else {
    GST_BUFFER_TIMESTAMP (subbuf) = GST_BUFFER_TIMESTAMP (buf);
  }
  GST_BUFFER_DURATION (subbuf) =
    gst_util_uint64_scale (samples, GST_SECOND, wfdlpcmdec->rate);

  wfdlpcmdec->next_timestamp = 
    GST_BUFFER_TIMESTAMP (subbuf) + GST_BUFFER_DURATION (subbuf);

  gst_buffer_unref (buf);

  return gst_pad_push (wfdlpcmdec->srcpad, subbuf);
}


/* entry point to initialize the plug-in
 * initialize the plug-in itself
 * register the element factories and other features
 */
static gboolean
wfdlpcmdec_init (GstPlugin * wfdlpcmdec)
{
  /* debug category for fltering log messages
   *
   * exchange the string 'Template wfdlpcmdec' with your description
   */
  GST_DEBUG_CATEGORY_INIT (gst_wfdlpcmdec_debug, "wfdlpcmdec",
      0, "Decode WFD LPCM into raw audio");

  return gst_element_register (wfdlpcmdec, "wfdlpcmdec", GST_RANK_PRIMARY,
      GST_TYPE_WFDLPCMDEC);
}

/* PACKAGE: this is usually set by autotools depending on some _INIT macro
 * in configure.ac and then written into and defined in config.h, but we can
 * just set it ourselves here in case someone doesn't use autotools to
 * compile this code. GST_PLUGIN_DEFINE needs PACKAGE to be defined.
 */
#ifndef PACKAGE
#define PACKAGE "myfirstwfdlpcmdec"
#endif

/* gstreamer looks for this structure to register wfdlpcmdecs
 *
 * exchange the string 'Template wfdlpcmdec' with your wfdlpcmdec description
 */
GST_PLUGIN_DEFINE (
    GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    "wfdlpcmdec",
    "Decode WFD LPCM into raw audio",
    wfdlpcmdec_init,
    VERSION,
    "LGPL",
    "GStreamer",
    "Unknown package origin"
)
